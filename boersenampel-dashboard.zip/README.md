# Börsenampel Dashboard

Ein einfaches Dashboard zur Marktphasen-Visualisierung mit Live-Daten von Yahoo Finance. Bereit für Deployment auf Vercel.

## Schritte

1. Repository in GitHub hochladen
2. Bei [https://vercel.com](https://vercel.com) anmelden
3. Neues Projekt anlegen und dieses Repository verbinden
